<?php
// created: 2014-12-02 15:52:13
$manifest = array (
  'acceptable_sugar_flavors' => 
  array (
    0 => 'CE',
  ),
  'acceptable_sugar_versions' => 
  array (
    'exact_matches' => 
    array (
      0 => '6.5.0',
      10 => '6.5.1',
      11 => '6.5.10',
      12 => '6.5.11',
      13 => '6.5.12',
      14 => '6.5.13',
      15 => '6.5.14',
      16 => '6.5.15',
      17 => '6.5.16',
      18 => '6.5.17',
      19 => '6.5.18',
      20 => '6.5.19',
      21 => '6.5.2',
      22 => '6.5.3',
      23 => '6.5.4',
      24 => '6.5.5',
      25 => '6.5.6',
      26 => '6.5.7',
      27 => '6.5.8',
      28 => '6.5.9',
    ),
    'regex_matches' => 
    array (
    ),
  ),
  'author' => 'SugarCRM, Inc.',
  'copy_files' => 
  array (
    'from_dir' => 'SugarCE-Upgrade-6.5.x-to-6.5.20',
    'to_dir' => '',
    'force_copy' => 
    array (
    ),
  ),
  'description' => '',
  'icon' => '',
  'is_uninstallable' => false,
  'offline_client_applicable' => true,
  'name' => 'SugarCE',
  'published_date' => '2014-12-02 15:52:13',
  'type' => 'patch',
  'version' => '6.5.20',
  'flavor' => 'CE',
);
?>
