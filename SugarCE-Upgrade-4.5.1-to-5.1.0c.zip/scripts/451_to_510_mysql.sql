-- MySQL upgrade script for Sugar 4.5.1 to 5.1.0

--
-- TABLES modified from 451 to 510
--

-- Moving outbound_email table to the top. Login has a dependency on it so it must be created.
CREATE TABLE `outbound_email` (
		  `id` char(36) NOT NULL default '',
		  `name` varchar(50) NOT NULL default '',
		  `type` varchar(6) NOT NULL default 'user',
		  `user_id` char(36) NOT NULL default '',
		  `mail_sendtype` varchar(8) NOT NULL default 'sendmail',
		  `mail_smtpserver` varchar(100) default NULL,
		  `mail_smtpport` int(5) default NULL,
		  `mail_smtpuser` varchar(100) default NULL,
		  `mail_smtppass` varchar(100) default NULL,
		  `mail_smtpauth_req` tinyint(1) default '0',
		  `mail_smtpssl` tinyint(1) default '0',
		  PRIMARY KEY  (`id`),
		  KEY `oe_user_id_idx` (`id`,`user_id`)
) CHARACTER SET utf8 COLLATE utf8_general_ci;

-- documents
ALTER TABLE `documents` DROP COLUMN `mail_merge_document`,
    modify column `id` char(36)  NOT NULL,



    modify column `deleted` bool  DEFAULT '0';


-- project task
UPDATE `project_task` set `milestone_flag`='0' where `milestone_flag` in ('',null,'off');
UPDATE `project_task` set `milestone_flag`='1' where `milestone_flag` != '0';
ALTER TABLE `project_task` modify column `milestone_flag` bool  DEFAULT '0'  NULL ;


-- tasks
UPDATE `tasks` set date_due_flag='0' where date_due_flag in ('',null,'off');
UPDATE `tasks` set date_due_flag='1' where date_due_flag != '0';
UPDATE `tasks` set `date_start_flag`='0' where `date_start_flag` in ('',null,'off');
UPDATE `tasks` set `date_start_flag`='1' where `date_start_flag` != '0';

ALTER TABLE `tasks` modify column `date_due_flag` bool  DEFAULT '1' NULL,
    modify column `date_due` datetime  NULL,
    modify column `date_start_flag` bool  DEFAULT '1' NULL,
    modify column `deleted` bool  DEFAULT '0' NULL,
    modify column `date_start` datetime  NULL,
    modify column `date_entered` datetime  NULL,
    modify column `date_modified` datetime  NULL,




	DROP INDEX `idx_tsk_name`,
	ADD  INDEX idx_tsk_name (name),
    DROP INDEX idx_task_con_del,
    ADD  INDEX idx_task_con_del (contact_id, deleted),
    DROP INDEX idx_task_par_del,
    ADD  INDEX idx_task_par_del (parent_id, parent_type, deleted);


UPDATE `tasks` set `date_start` = CONCAT(date(`date_start`),' ',`time_start`),
			 `date_due`= CONCAT(date(`date_due`),' ',`time_due`);
ALTER TABLE `tasks` drop column `time_start`, drop column `time_due`;


















ALTER TABLE users ADD  INDEX idx_user_name(user_name,is_group,status,last_name,first_name,id);


-- boolean and date-time

ALTER TABLE `calls` modify `date_start` datetime NULL;
UPDATE `calls` set `date_start` = CONCAT(date(`date_start`),' ',`time_start`);
ALTER TABLE `calls` drop column `time_start`,
                    modify column `date_entered` datetime  NULL,
                    modify column `date_modified` datetime  NULL,
                    modify column `deleted` bool  DEFAULT '0';







ALTER TABLE `calls`  DROP INDEX `idx_call_name`,ADD  INDEX idx_call_name (name),
    ADD  INDEX idx_status (status),
    ADD  INDEX idx_calls_date_start (date_start);

ALTER TABLE `meetings` modify `date_start` datetime;
UPDATE `meetings`  set `date_start` = CONCAT(date(`date_start`),' ',`time_start`);
ALTER TABLE `meetings` drop column `time_start`,
    modify column `date_start` datetime  NULL,
    modify column `date_entered` datetime  NULL,
    modify column `date_modified` datetime  NULL,
    MODIFY COLUMN deleted bool DEFAULT '0' NULL,
    ADD  INDEX idx_meet_stat_del (assigned_user_id, status, deleted);





ALTER TABLE `email_marketing` modify `date_start` datetime NULL;
UPDATE `email_marketing`  set `date_start` = CONCAT(date(`date_start`),' ',`time_start`);

ALTER TABLE `email_marketing` add column `reply_to_name` varchar(100)  NULL,
    add column `reply_to_addr` varchar(100)  NULL,
    drop column `time_start`;

-- More depending on database diffs between 451 and 500

UPDATE `leads` set `do_not_call`='0' where `do_not_call` in ('',null,'off');
UPDATE `leads` set `do_not_call`='1' where `do_not_call` != '0';

ALTER TABLE `leads` MODIFY COLUMN `first_name` varchar( 100 ) NULL ,
    MODIFY COLUMN `last_name` varchar( 100 ) ,
    MODIFY COLUMN do_not_call bool DEFAULT '0' NULL ,
    MODIFY COLUMN department VARCHAR( 100 ),
    MODIFY COLUMN `date_entered` datetime  NULL,
    MODIFY column `date_modified` datetime  NULL,
    MODIFY COLUMN deleted bool DEFAULT '0' NULL,
    ADD COLUMN `assistant` varchar( 75 ) NULL ,
    ADD COLUMN `assistant_phone` varchar(25) NULL ,
    MODIFY COLUMN `account_name` varchar(255) NULL ,
    MODIFY COLUMN `primary_address_country` varchar(255),
    MODIFY COLUMN `alt_address_country` varchar(255);






ALTER TABLE `leads` ADD INDEX idx_del_user( deleted, assigned_user_id );
ALTER TABLE `leads` ADD INDEX idx_lead_acct_name_first(account_name,deleted);

UPDATE `contacts` set `do_not_call`='0' where `do_not_call` in ('',null,'off');
UPDATE `contacts` set `do_not_call`='1' where `do_not_call` != '0';

ALTER TABLE `contacts` modify column `last_name` varchar(100) NULL,
    modify column `do_not_call` bool  DEFAULT '0' NULL,
    modify column department VARCHAR(255),
    modify column `title` varchar(100)  NULL,
    modify column `date_entered` datetime  NULL,
    modify column `date_modified` datetime  NULL,
    MODIFY COLUMN `deleted` bool DEFAULT '0' NULL,
    MODIFY COLUMN `primary_address_country` varchar(255),
    MODIFY COLUMN `alt_address_country` varchar(255),
    ADD  INDEX idx_reports_to_id (reports_to_id),
    ADD  INDEX idx_del_id_user (deleted, id, assigned_user_id),
    DROP INDEX idx_contacts_del_last,
    ADD  INDEX idx_contacts_del_last (deleted, last_name),
    DROP INDEX idx_cont_del_reports,
    ADD  INDEX idx_cont_del_reports (deleted, reports_to_id, last_name);






ALTER TABLE `accounts` modify column `modified_user_id` char(36)  NULL,
    modify column `date_entered` datetime  NULL,
    modify column `date_modified` datetime  NULL,
    modify COLUMN `deleted` bool DEFAULT '0' NULL,
    MODIFY COLUMN `billing_address_country` varchar(255),
    MODIFY COLUMN `shipping_address_country` varchar(255);






ALTER TABLE `opportunities` DROP INDEX `idx_opp_name`,
    modify column `date_entered` datetime  NULL,
    modify column `date_modified` datetime  NULL,
    modify COLUMN `deleted` bool DEFAULT '0' NULL,
    ADD  INDEX idx_opp_name (name);




UPDATE `cases` set name='Unspecified' where name is null;
ALTER TABLE `cases` modify column `name` varchar(255) NULL,
    modify column `date_entered` datetime  NULL,
    modify column `date_modified` datetime  NULL,
    modify COLUMN `deleted` bool DEFAULT '0' NULL,
    modify column `modified_user_id` char(36)  NULL,
    add column `type` varchar(255)  NULL,



    add column `work_log` text  NULL;






ALTER TABLE `cases`  DROP INDEX `idx_case_name`,
    ADD  INDEX idx_case_name (name),
    ADD  INDEX idx_account_id (account_id),
    ADD  INDEX idx_cases_stat_del (assigned_user_id, status, deleted),
    ADD  UNIQUE `casesnumk` (case_number);









-- Files Table modifications
ALTER TABLE `files` modify column `id` varchar(36),
                    modify column `assigned_user_id` varchar(36);

ALTER TABLE `notes`  DROP INDEX `idx_note_name`,
    ADD  INDEX idx_note_name (name);

ALTER TABLE `emailman` ADD  INDEX idx_eman_relid_reltype_id (related_id, related_type, campaign_id);

ALTER TABLE `emails` add column `date_sent` datetime NULL,modify column message_id VARCHAR(255);
UPDATE `emails` set `date_sent` = CONCAT(date(`date_start`),' ',`time_start`);

ALTER TABLE `emails` add column `flagged` bool NULL;
ALTER TABLE `emails` add column `reply_to_status` bool NULL;

ALTER TABLE `upgrade_history` add column `enabled` bool  DEFAULT '1' NULL ;












































ALTER TABLE `bugs` modify column `assigned_user_id` char(36)  NULL,
    modify column `name` varchar(255),
    modify column `modified_user_id` char(36)  NULL,
    modify column `created_by` char(36)  NULL,
    modify column `date_entered` datetime  NULL,
    modify column `date_modified` datetime  NULL,



    modify column deleted bool  DEFAULT '0' NULL,
    ADD  UNIQUE bugsnumk (bug_number),
    DROP INDEX `idx_bug_name`,
    ADD  INDEX idx_bug_name (name);





ALTER TABLE `campaigns` modify column `deleted` bool DEFAULT '0' NULL;





UPDATE `prospects` set `do_not_call`='0' where `do_not_call` in ('',null,'off');
UPDATE `prospects` set `do_not_call`='1' where `do_not_call` != '0';

ALTER TABLE `prospects` modify column `deleted` bool  DEFAULT '0',
    modify column `last_name` varchar(100),
    modify column `title` varchar(100)  NULL,
    modify column `do_not_call` bool  DEFAULT '0' NULL,
    modify column `date_entered` datetime  NULL,
    modify column `date_modified` datetime  NULL,
    MODIFY COLUMN `primary_address_country` varchar(255),
    MODIFY COLUMN `alt_address_country` varchar(255),
    DROP INDEX idx_prospects_last_first,
    ADD  INDEX idx_prospects_last_first (last_name, first_name, deleted),
    DROP INDEX idx_prospecs_del_last,
    ADD  INDEX idx_prospecs_del_last (last_name, deleted);








ALTER TABLE `fields_meta_data` add column `vname` varchar(255)  NULL,
    add column `comments` varchar(255)  NULL,
    add column `type` varchar(255)  NULL,
    add column `len` int(11)  NULL,
    add column `required` bool  DEFAULT '0' NULL,
    add column `massupdate` bool  DEFAULT '0' NULL,
    add column `reportable` bool  DEFAULT '1' NULL,
    ADD  INDEX idx_meta_cm_del (custom_module, deleted);


ALTER TABLE `inbound_email` add column `is_personal` bool  DEFAULT '0' NOT NULL,
    modify column `stored_options` text NULL,
    add column `groupfolder_id` char(36) NULL;

ALTER TABLE `accounts_contacts` ADD  INDEX idx_contid_del_accid (contact_id, deleted, account_id);
ALTER TABLE `accounts_opportunities` ADD  INDEX idx_oppid_del_accid (opportunity_id, deleted, account_id);

ALTER TABLE `tracker` modify column user_id varchar(36)  NULL,
    add column `action` varchar(255)  NULL,
    modify column `module_name` varchar(255)  NULL,
    modify column `item_id` varchar(36)  NULL,
    add column `session_id` int(11)  NULL,
    add column `visible` bool  DEFAULT 0 NULL,
    ADD INDEX idx_tracker_iid(item_id),
    ADD INDEX idx_tracker_userid_vis_id(user_id,visible,id),
    ADD INDEX idx_tracker_userid_itemid_vis(user_id,item_id,visible);

UPDATE `tracker` set visible = '1';


CREATE TABLE `email_addresses` (
				id char(36)  NOT NULL ,
				email_address varchar(255)  NOT NULL ,
				email_address_caps varchar(255)  NOT NULL ,
				invalid_email bool  DEFAULT '0' NULL ,
				opt_out bool  DEFAULT '0' NULL ,
				date_created datetime  NULL ,
				date_modified datetime  NULL ,
				deleted bool  DEFAULT '0' NULL  ,
				PRIMARY KEY (id),
                KEY idx_ea_caps_opt_out_invalid (email_address_caps,opt_out,invalid_email),
				KEY idx_ea_opt_out_invalid (email_address, opt_out, invalid_email))
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `email_addr_bean_rel` (
			  `id` char(36) NOT NULL default '',
			  `email_address_id` char(36) NOT NULL default '',
			  `bean_id` char(36) NOT NULL default '',
			  `bean_module` varchar(25) NOT NULL default '',
			  `primary_address`  bool  DEFAULT '0' NULL,
			  `reply_to_address`  bool  DEFAULT '0' NULL,
			  `date_created` datetime default NULL,
			  `date_modified` datetime default NULL,
			  `deleted` bool  DEFAULT '0' NULL,
			  PRIMARY KEY  (`id`),
			  KEY `idx_email_address_id` (`email_address_id`),
			  KEY `idx_bean_id` (`bean_id`,`bean_module`)
) CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `emails_text` (
			  `email_id` varchar(36) NOT NULL default '',
			  `from_addr` varchar(255),
			  `to_addrs` text,
			  `cc_addrs` text,
			  `bcc_addrs` text,
			  `description` longtext,
			  `description_html` longtext,
			  `raw_source` longtext,
			  `deleted` tinyint(1) default '0',
			  `reply_to_addr` varchar(255),
			  PRIMARY KEY  (`email_id`),
			  KEY `emails_textfromaddr` (`from_addr`)
)CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `emails_beans` (
			  `id` varchar(36) NOT NULL default '',
			  `email_id` varchar(36) default NULL,
			  `bean_id` varchar(36) default NULL,
			  `bean_module` varchar(36) default NULL,
			  `campaign_data` text,
			  `date_modified` datetime default NULL,
			  `deleted` tinyint(1) NOT NULL default '0',
			  PRIMARY KEY  (`id`),
			  KEY `idx_emails_beans_bean_id` (`bean_id`),
			  KEY `idx_emails_beans_email_bean` (`email_id`,`bean_id`,`deleted`)
)CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `emails_email_addr_rel` (
			  `id` char(36) NOT NULL default '',
			  `email_id` char(36) NOT NULL default '',
			  `address_type` varchar(4) NOT NULL default '',
			  `email_address_id` char(36) NOT NULL default '',
			  `deleted` tinyint(1) default '0',
			  PRIMARY KEY  (`id`),
			  KEY `idx_eearl_email_id` (`email_id`,`address_type`),
			  KEY `idx_eearl_address_id` (`email_address_id`)
) CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `folders` (
			id char(36)  NOT NULL ,
			name varchar(25)  NOT NULL ,
			parent_folder char(36)  DEFAULT '' NULL,
			has_child bool  DEFAULT '0' NULL ,
			is_group bool  DEFAULT '0' NULL ,
			is_dynamic bool  DEFAULT '0' NULL ,
			dynamic_query text  NULL ,
			assign_to_id char(36)  NULL ,
			folder_type varchar(25)  NULL ,



			created_by char(36)  NOT NULL ,
			modified_by char(36)  NOT NULL ,
			deleted bool  DEFAULT '0' NULL  ,
			PRIMARY KEY (id),
			KEY idx_parent_folder (parent_folder)
) CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `folders_subscriptions` (id char(36)  NOT NULL ,folder_id char(36)  NOT NULL ,assigned_user_id char(36)  NOT NULL  , PRIMARY KEY (id),   KEY idx_folder_id_assigned_user_id (folder_id, assigned_user_id)) CHARACTER SET utf8 COLLATE utf8_general_ci;
CREATE TABLE `folders_rel` (id char(36)  NOT NULL ,folder_id char(36)  NOT NULL ,polymorphic_module varchar(25)  NOT NULL ,polymorphic_id char(36)  NOT NULL ,deleted bool  DEFAULT '0' NULL  , PRIMARY KEY (id),   KEY idx_poly_module_poly_id (polymorphic_module, polymorphic_id), KEY idx_folders_rel_folder_id(folder_id)) CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `address_book` (assigned_user_id char(36)  NOT NULL ,bean varchar(50)  NOT NULL ,bean_id char(36)  NOT NULL  , KEY ab_user_bean_idx (assigned_user_id, bean)) CHARACTER SET utf8 COLLATE utf8_general_ci;






CREATE TABLE `inbound_email_cache_ts` (id varchar(255)  NOT NULL ,ie_timestamp int unsigned  NOT NULL  , PRIMARY KEY (id)) CHARACTER SET utf8 COLLATE utf8_general_ci;

ALTER TABLE `acl_actions` add index idx_category_name (category, name);




CREATE TABLE `email_cache` (
  `ie_id` char(36) NOT NULL,
  `mbox` varchar(60) NOT NULL,
  `subject` varchar(255) default NULL,
  `fromaddr` varchar(100)NULL,
  `toaddr` varchar(255) NULL,
  `senddate` datetime NOT NULL,
  `message_id` varchar(255) default NULL,
  `mailsize` int(10) unsigned NOT NULL,
  `imap_uid` int(10) unsigned NOT NULL,
  `msgno` int(10) unsigned default NULL,
  `recent` tinyint(4) NOT NULL,
  `flagged` tinyint(4) NOT NULL,
  `answered` tinyint(4) NOT NULL,
  `deleted` tinyint(4) NOT NULL,
  `seen` tinyint(4) NOT NULL,
  `draft` tinyint(4) NOT NULL,
  KEY `idx_ie_id` (`ie_id`),
  KEY `idx_mail_date` (`ie_id`,`mbox`,`senddate`),
  KEY `idx_mail_from` (`ie_id`,`mbox`,`fromaddr`),
  KEY `idx_mail_subj` (`subject`)
)CHARACTER SET utf8 COLLATE utf8_general_ci;


-- MySQL upgrade script for Sugar 5.0.0 to 5.1.0
--
-- TABLES modified from 500 to 510
--
-- import maps
ALTER TABLE `import_maps` modify column `name` varchar(254) NOT NULL,
                          add column `enclosure` varchar(1) NOT NULL default ' ',
                          add column `delimiter` varchar(1) NOT NULL default ',',
                          add column `default_values` blob;


-- inbound email
ALTER TABLE `inbound_email` modify column `mailbox` text NOT NULL;
-- project task
ALTER TABLE `project_task` add column `status` varchar(255)  NULL,
                           add column `order_number` int(11)  default '1',
                           add column `task_number` int(11)  default NULL,
                           add column `estimated_effort` int(11)  default NULL,
                           add column `utilization` int(11)  default '100';

-- tracker table changes
ALTER TABLE `tracker` add column `monitor_id` char(36)  NULL,



                      add column deleted tinyint(1)default '0',
                      modify column session_id varchar(36) NULL,
                      ADD  INDEX idx_tracker_monitor_id (monitor_id);


ALTER TABLE accounts   modify column account_type varchar(50)  NULL ,
                       modify column industry varchar(50)  NULL ;
ALTER TABLE users_last_import add column import_module varchar(36)  NULL;

-- ALTER TABLE fields_meta_data modify column default_value varchar(255)  NULL;
ALTER TABLE fields_meta_data add column importable varchar(255)  NULL ;

ALTER TABLE product_templates modify column name varchar(50)  NULL ,
                              modify column pricing_formula varchar(25)  NULL;
CREATE TABLE calls_leads (id varchar(36)  NOT NULL ,call_id varchar(36)  NULL ,lead_id varchar(36)  NULL ,required varchar(1)  DEFAULT '1' NULL ,accept_status varchar(25)  DEFAULT 'none' NULL ,date_modified datetime  NULL ,deleted bool  DEFAULT '0' NOT NULL  , PRIMARY KEY (id),   KEY idx_lead_call_call (call_id),   KEY idx_lead_call_lead (lead_id),   KEY idx_call_lead (call_id, lead_id)) CHARACTER SET utf8 COLLATE utf8_general_ci;
CREATE TABLE meetings_leads (id varchar(36)  NOT NULL ,meeting_id varchar(36)  NULL ,lead_id varchar(36)  NULL ,required varchar(1)  DEFAULT '1' NULL ,accept_status varchar(25)  DEFAULT 'none' NULL ,date_modified datetime  NULL ,deleted bool  DEFAULT '0' NOT NULL  , PRIMARY KEY (id),   KEY idx_lead_meeting_meeting (meeting_id),   KEY idx_lead_meeting_lead (lead_id),   KEY idx_meeting_lead (meeting_id, lead_id)) CHARACTER SET utf8 COLLATE utf8_general_ci;


























































































