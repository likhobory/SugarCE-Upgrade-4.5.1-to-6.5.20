<?php

if(!defined('sugarEntry'))define('sugarEntry', true);

require_once('include/utils.php');
require_once('include/database/PearDatabase.php');
require_once('include/database/DBManager.php');
require_once('include/database/DBManagerFactory.php');
require_once('include/entryPoint.php');

/**
 * upgrade_portal
 * This is the entry point into this file for upgrade a 4.5.x to 5.0.x to handle portal issues.
 * This function queries the contacts table for contacts whose portal_active
 * value is set to 1.  Then it processes 10 contacts at a time to search for cases
 * and bugs they may be related to that need to have the portal_viewable flag set to 1.
 */
function upgrade_portal5(){






























}

/**
 * process
 * function to handle processing 10 contacts at a time (private)
 */
function process($db, $contacts) {

	//First get all the case ids where we will set portal_viewable flag to 1
	//Query contacts_cases
	$cases = array();
	
	$query = "select case_id from contacts_cases where contact_id in ($contacts)";
	
	$result = $db->query($query);
	while($row = $db->fetchByAssoc($result)) {
	      $cases[$row['case_id']] = $row['case_id'];
	}
	
	//Query accounts_contacts
	$query = "SELECT c.id from cases c, accounts_contacts ac where c.account_id = ac.account_id and ac.contact_id in ($contacts)";
	
	$result = $db->query($query);
	while($row = $db->fetchByAssoc($result)) {
	      $cases[$row['id']] = "'" . $row['id'] . "'";
	}
	
	$i = 0;
	$in_query = '';
	
	foreach($cases as $case_id) {
	   $in_query .= ',' . $case_id;
	   if(++$i % 10 == 0) {
	   	  $in_query = substr($in_query, 1);
	   	  $query = "UPDATE cases set portal_viewable = 1 where id IN ($in_query)";
	   	  update_query($db, $query);
	      $in_query = "";  	
	   }
	}
	
	if(!empty($in_query)) {
		$in_query = substr($in_query, 1);
		$query = "UPDATE cases set portal_viewable = 1 where id IN ($in_query)";
		update_query($db, $query);
	}
	
	
	//First get all the bugs ids where we will set portal_viewable flag to 1
	//Query contacts_bugs
	$bugs = array();
	
	$query = "select bug_id from contacts_bugs where contact_id in ($contacts)";
	
	$result = $db->query($query);
	while($row = $db->fetchByAssoc($result)) {
	      $bugs[$row['bug_id']] = "'" . $row['bug_id'] . "'";
	}
	
	//Query accounts_bugs
	$query = "SELECT ab.bug_id from accounts_bugs ab, accounts_contacts ac where ab.account_id = ac.account_id and ac.contact_id in ($contacts)";
	
	$result = $db->query($query);
	while($row = $db->fetchByAssoc($result)) {
	      $bugs[$row['bug_id']] = "'" . $row['bug_id'] . "'";
	}
	
	$i = 0;
	$in_query = "";
	
	foreach($bugs as $bug_id) {
	   $in_query .= ',' . $bug_id;
	   if(++$i % 10 == 0) {
	   	  $in_query = substr($in_query, 1);
	   	  $query = "UPDATE bugs set portal_viewable = 1 where id IN ($in_query)";
	   	  update_query($db, $query);
	      $in_query = "";  	
	   }
	}
	
	if(!empty($in_query)) {
		$in_query = substr($in_query, 1);
		$query = "UPDATE bugs set portal_viewable = 1 where id IN ($in_query)";
		update_query($db, $query);
	}

}

/**
 * update_query
 * function that calls the update statement (private)
 */
function update_query($db, $query) {
    $db->query($query);
}



























































?>