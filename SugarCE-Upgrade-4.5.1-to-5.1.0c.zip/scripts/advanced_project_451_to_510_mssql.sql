-- project
ALTER TABLE [project] ADD [estimated_start_date] [datetime] CONSTRAINT [DF_estimated_start_date] DEFAULT getdate() NOT NULL;
ALTER TABLE [project] ADD [status] [varchar] (255);
UPDATE [project] SET [status] = 'Draft';
ALTER TABLE [project] ADD [priority] [varchar] (255);
UPDATE [project] SET [priority] = 'Medium';




ALTER TABLE [project] ADD [estimated_end_date] [datetime] CONSTRAINT [DF_estimated_end_date] DEFAULT getdate() NOT NULL;

-- project_task
ALTER TABLE [project_task] ADD [time_start_backed] datetime;
UPDATE [project_task] SET [time_start_backed] = [time_start];
ALTER TABLE [project_task] DROP COLUMN [time_start];
ALTER TABLE [project_task] ADD [time_start] [int];

ALTER TABLE [project_task] ADD [time_finish] [int];
UPDATE [project_task] SET [time_finish] = CONVERT([int], DATEPART(hh, [time_due]));

ALTER TABLE [project_task] ADD [project_id] [varchar] (36);
UPDATE [project_task] SET [project_id] = [parent_id];
ALTER TABLE [project_task] ADD [project_task_id] [int];
UPDATE [project_task] set [project_task_id]=1;
ALTER TABLE [project_task] ALTER COLUMN [project_task_id] [int] NOT NULL;




ALTER TABLE [project_task] ADD [predecessors] [text];

ALTER TABLE [project_task] ADD [date_finish] [datetime];
UPDATE [project_task] SET [date_finish] = [date_due];

ALTER TABLE [project_task] ADD [duration] [int];
UPDATE [project_task] set [duration]=0;
ALTER TABLE [project_task] ALTER COLUMN [duration] [int] NOT NULL;

ALTER TABLE [project_task] ADD [duration_unit] [text];
UPDATE [project_task] SET [duration_unit]='Days';
ALTER TABLE [project_task] ALTER COLUMN [duration_unit] [text] NOT NULL;

ALTER TABLE [project_task] ADD [actual_duration] [int];
UPDATE [project_task] SET [actual_duration]=CEILING(actual_effort/8);
ALTER TABLE [project_task] ALTER COLUMN [percent_complete] [int];
UPDATE [project_task] SET [percent_complete]=0 WHERE [percent_complete] IS NULL;
ALTER TABLE [project_task] ADD [parent_task_id] [int];

ALTER TABLE [project_task] ALTER COLUMN [parent_id] [varchar] (36) NULL;





-- projects_accounts
CREATE TABLE [projects_accounts] (
  [id] [varchar](36) NOT NULL,
  [account_id] [varchar](36) NULL,
  [project_id] [varchar](36) NULL,
  [date_modified] [datetime] NULL,
  [deleted] [bit] NOT NULL default (0)
) ;
ALTER TABLE [projects_accounts] ADD CONSTRAINT [pk_projects_accounts] PRIMARY KEY CLUSTERED  ([id]);
CREATE NONCLUSTERED INDEX [idx_proj_acct_proj] ON [projects_accounts]([project_id]);
CREATE NONCLUSTERED INDEX [idx_proj_acct_acct] ON [projects_accounts]([account_id]);
CREATE NONCLUSTERED INDEX [projects_accounts_alt] ON [projects_accounts]([project_id],[account_id]);

-- projects_bugs
CREATE TABLE [projects_bugs] (
  [id] [varchar](36) NOT NULL,
  [bug_id] [varchar](36) NULL,
  [project_id] [varchar](36) NULL,
  [date_modified] [datetime] NULL,
  [deleted] [bit] NOT NULL default (0)
);
ALTER TABLE [projects_bugs] ADD CONSTRAINT [pk_projects_bugs] PRIMARY KEY CLUSTERED  ([id]);
CREATE NONCLUSTERED INDEX [idx_proj_bug_proj] ON [projects_bugs]([project_id]);
CREATE NONCLUSTERED INDEX [idx_proj_bug_bug] ON [projects_bugs]([bug_id]);
CREATE NONCLUSTERED INDEX [projects_bugs_alt] ON [projects_bugs]([project_id],[bug_id]);

-- projects_cases
CREATE TABLE [projects_cases] (
  [id] [varchar](36) NOT NULL,
  [case_id] [varchar](36) NULL,
  [project_id] [varchar](36) NULL,
  [date_modified] datetime NULL,
  [deleted] [bit] NOT NULL default (0)
);
ALTER TABLE [projects_cases] ADD CONSTRAINT [pk_projects_cases] PRIMARY KEY CLUSTERED  ([id]);
CREATE NONCLUSTERED INDEX [idx_proj_case_proj] ON [projects_cases]([project_id]);
CREATE NONCLUSTERED INDEX [idx_proj_case_case] ON [projects_cases]([case_id]);
CREATE NONCLUSTERED INDEX [projects_cases_alt] ON [projects_cases]([project_id],[case_id]);
-- projects_contacts
CREATE TABLE [projects_contacts] (
  [id] [varchar](36) NOT NULL,
  [contact_id] [varchar](36) NULL,
  [project_id] [varchar](36) NULL,
  [date_modified] [datetime] NULL,
  [deleted] [bit] NOT NULL default (0)
);
ALTER TABLE [projects_contacts] ADD CONSTRAINT [pk_projects_contacts] PRIMARY KEY CLUSTERED  ([id]);
CREATE NONCLUSTERED INDEX [idx_proj_con_proj] ON [projects_contacts]([project_id]);
CREATE NONCLUSTERED INDEX [idx_proj_con_con] ON [projects_contacts]([contact_id]);
CREATE NONCLUSTERED INDEX [projects_contacts_alt] ON [projects_contacts]([project_id],[contact_id]);

-- projects_opportunities
CREATE TABLE [projects_opportunities](
  [id] [varchar](36) NOT NULL,
  [opportunity_id] [varchar](36) NULL,
  [project_id] [varchar](36) NULL,
  [date_modified] [datetime] NULL,
  [deleted] [bit] NOT NULL default (0)
);
ALTER TABLE [projects_opportunities] ADD CONSTRAINT [pk_projects_opportunities] PRIMARY KEY CLUSTERED  ([id]);
CREATE NONCLUSTERED INDEX [idx_proj_opp_proj] ON [projects_opportunities]([project_id]);
CREATE NONCLUSTERED INDEX [idx_proj_opp_opp] ON [projects_opportunities]([opportunity_id]);
CREATE NONCLUSTERED INDEX [projects_opportunities_alt] ON [projects_opportunities]([project_id],[opportunity_id]);


-- projects_products
CREATE TABLE [projects_products] (
  [id] [varchar](36) NOT NULL,
  [product_id] [varchar](36) NULL,
  [project_id] [varchar](36) NULL,
  [date_modified] [datetime] NULL,
  [deleted] [bit] NOT NULL default (0)
);
ALTER TABLE [projects_products] ADD CONSTRAINT [pk_projects_products] PRIMARY KEY CLUSTERED  ([id]);
CREATE NONCLUSTERED INDEX [idx_proj_prod_project] ON [projects_products]([project_id]);
CREATE NONCLUSTERED INDEX [idx_proj_prod_product] ON [projects_products]([product_id]);
CREATE NONCLUSTERED INDEX [projects_products_alt] ON [projects_products]([project_id],[product_id]);






























































